const mongoDbConnectionString = "mongodb+srv://testUser:testtest@cluster0-otgof.mongodb.net/test";

module.exports = mongoDbConnectionString;